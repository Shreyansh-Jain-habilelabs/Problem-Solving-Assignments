<!-- Q1.) [2,3,-2,-4,6,7,8,1] provide the max sum of "n" consecutive number (O(n^2) && O(n).
Q2.) find the longest sub string of a string containing distinct characters.
Q3.) find the 3rd largest number.
Q4.) [2,3,-2,-4,6,7,8,1] provide the min sum of "n" consecutive number.
Q5.) largest sub-array of distinct elements of and array.
// make function pass array and num find no. of subarrays whore product is less then the passed number; -->